#include <Arduino.h>
#include "ledSymbols.h"

#define LEDDELAY 2 //Delay between each digit display
#define SCROLLSPEED 50 //Delay (ms) between each character shift
#define BLINKRATE 100 // Delay between each blink

//Led driver/shift register pin definitions
const int latchPin = 7;
const int clockPin = 6;
const int dataPin = 5;

//Led channel pins
const byte ch1 = A0;
const byte ch2 = A1;
const byte ch3 = A2;
const byte ch4 = A3;

//Stores the current number on display + decimal point placement
byte ledDigit[5] = {0}; 

void shiftOut(int myDataPin, int myClockPin, byte myDataOut) {
  // This shifts 8 bits out MSB first,
  //on the rising edge of the clock,
  //clock idles low

  //internal function setup
  int i=0;
  int pinState;
  pinMode(myClockPin, OUTPUT);
  pinMode(myDataPin, OUTPUT);

  //clear everything out just in case to
  //prepare shift register for bit shifting
  digitalWrite(myDataPin, 0);
  digitalWrite(myClockPin, 0);

  //for each bit in the byte myDataOut
  //NOTICE THAT WE ARE COUNTING DOWN in our for loop
  //This means that %00000001 or "1" will go through such
  //that it will be pin Q0 that lights.
  for (i=7; i>=0; i--)  {
    digitalWrite(myClockPin, 0);

    //if the value passed to myDataOut and a bitmask result
    // true then... so if we are at i=6 and our value is
    // %11010100 it would the code compares it to %01000000
    // and proceeds to set pinState to 1.
    if ( myDataOut & (1<<i) ) {
      pinState= 1;
    }
    else { 
      pinState= 0;
    }

    //Sets the pin to HIGH or LOW depending on pinState
    digitalWrite(myDataPin, pinState);
    //register shifts bits on upstroke of clock pin  
    digitalWrite(myClockPin, 1);
    //zero the data pin after shift to prevent bleed through
    digitalWrite(myDataPin, 0);
  }

  //stop shifting
  digitalWrite(myClockPin, 0);
}



void setLedChannel(byte ledChannel) {
  switch (ledChannel) {
    case 1:
      digitalWrite(ch4, HIGH);
      digitalWrite(ch3, HIGH);
      digitalWrite(ch2, HIGH);
      digitalWrite(ch1, LOW);
      break;
    case 2:
      digitalWrite(ch4, HIGH);
      digitalWrite(ch3, HIGH);
      digitalWrite(ch1, HIGH);
      digitalWrite(ch2, LOW);
      break;
    case 3:
      digitalWrite(ch4, HIGH);
      digitalWrite(ch1, HIGH);
      digitalWrite(ch2, HIGH);
      digitalWrite(ch3, LOW);
      break;
    case 4:
      digitalWrite(ch1, HIGH);
      digitalWrite(ch2, HIGH);
      digitalWrite(ch3, HIGH);
      digitalWrite(ch4, LOW);
      break;
    default:
      digitalWrite(ch1, HIGH);
      digitalWrite(ch2, HIGH);
      digitalWrite(ch3, HIGH);
      digitalWrite(ch4, HIGH);
      break;
  }
}


void clearLedDisplay() {
  digitalWrite(ch1, HIGH);
  digitalWrite(ch2, HIGH);
  digitalWrite(ch3, HIGH);
  digitalWrite(ch4, HIGH);
}



void writeLedChar(byte ledDataPin, byte ledClockPin, byte ledLatchPin, byte ledChannel, char ledChar, byte decimalPointChannel) {
  clearLedDisplay();
  byte MSByte = 0;
  byte LSByte = 0;
  if ((ledChar >= '0') && (ledChar <= '9') && (decimalPointChannel == ledChannel)) {
    unsigned int decimalChar;
    decimalChar = ledNumbers[(ledChar-'0')] | ledNumbers[10];
    MSByte = (byte)(decimalChar/256);
    LSByte = (byte)(decimalChar%256);
    digitalWrite(ledLatchPin, LOW);
    shiftOut(ledDataPin, ledClockPin, MSByte);
    shiftOut(ledDataPin, ledClockPin, LSByte);
    digitalWrite(ledLatchPin, HIGH);
  }

  else if ((ledChar >= '0') && (ledChar <= (13 + '9'))) {
    MSByte = (byte)(ledNumbers[(ledChar-'0')]/256);
    LSByte = (byte)(ledNumbers[(ledChar-'0')]%256);
    digitalWrite(ledLatchPin, LOW);
    shiftOut(ledDataPin, ledClockPin, MSByte);
    shiftOut(ledDataPin, ledClockPin, LSByte);
    digitalWrite(ledLatchPin, HIGH);
  }

  else if((ledChar >= 'a') && (ledChar <= 'z')) {
    MSByte = (byte)(ledAlphabet[(ledChar-'a')]/256);
    LSByte = (byte)(ledAlphabet[(ledChar-'a')]%256);
    digitalWrite(ledLatchPin, LOW);
    shiftOut(ledDataPin, ledClockPin, MSByte);
    shiftOut(ledDataPin, ledClockPin, LSByte);
    digitalWrite(ledLatchPin, HIGH);
  }

  else {
    MSByte = 0x00;
    LSByte = 0x00;
    digitalWrite(ledLatchPin, LOW);
    shiftOut(ledDataPin, ledClockPin, MSByte);
    shiftOut(ledDataPin, ledClockPin, LSByte);
    digitalWrite(ledLatchPin, HIGH);
  }
      
  setLedChannel(ledChannel);
}

void refreshDisplay() {
  writeLedChar(dataPin, clockPin, latchPin, 1, ledDigit[0], ledDigit[4]);
  delay(LEDDELAY);
  writeLedChar(dataPin, clockPin, latchPin, 2, ledDigit[1], ledDigit[4]);
  delay(LEDDELAY);
  writeLedChar(dataPin, clockPin, latchPin, 3, ledDigit[2], ledDigit[4]);
  delay(LEDDELAY);
  writeLedChar(dataPin, clockPin, latchPin, 4, ledDigit[3], ledDigit[4]);
  delay(LEDDELAY);
}


void refreshDisplayDelay(int delayMilliseconds) {
  unsigned long startTime = millis();
    while(abs(millis() - startTime) < delayMilliseconds) {
      refreshDisplay();
    }
}


void blinkLedDisplay(int blinkTime) {
  unsigned long startTime = millis();
  while(millis()-startTime < blinkTime) {
    clearLedDisplay();
    delay(BLINKRATE);
    refreshDisplayDelay(BLINKRATE);
  }
}

void dispNumber(int intNumber, byte decimalPoint) {
  intNumber = constrain(intNumber, 0, 9999);
  decimalPoint = constrain(decimalPoint, 0, 4);
  ledDigit[0] = (intNumber / 1000) + '0';
  ledDigit[1] = ((intNumber % 1000) / 100) + '0';
  ledDigit[2] = ((intNumber % 100) / 10) + '0';
  ledDigit[3] = ((intNumber % 10)) + '0';
  ledDigit[4] = decimalPoint;
  if(intNumber<1000) ledDigit[0]=254;
  if(intNumber<100)  ledDigit[1]=254;
  if(intNumber<10)   ledDigit[2]=254;
  if(intNumber<1)    ledDigit[3]=254;
  //refreshDisplay();
}

void loadingAnimation() {
  static int i;
  ledDigit[4]=0;
  if((i>=0) && (i<4)) {
    ledDigit[i]=12 + '0';
    if(i>0) ledDigit[i-1]=254;
    else ledDigit[3]=254;
    refreshDisplayDelay(100);
    i++;
  }
  else i=0;
}

void dispString(char* displayedString, int speed = SCROLLSPEED) { 
  int i = 0, j=4;
  unsigned int previousChar;

  speed = constrain(speed, 0, 2000);
  ledDigit[0] = ledNumbers[11];
  ledDigit[1] = ledNumbers[11];
  ledDigit[2] = ledNumbers[11];
  ledDigit[3] = ledNumbers[11];
  ledDigit[4] = 0;

  while(displayedString[i]!='\0') {

    ledDigit[0] = ledDigit[1];
    ledDigit[1] = ledDigit[2];
    ledDigit[2] = ledDigit[3];
    ledDigit[3]  = displayedString[i];

    refreshDisplayDelay(speed);

    i++;
  }
}
