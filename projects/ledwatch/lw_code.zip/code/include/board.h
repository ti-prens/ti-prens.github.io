#ifndef __BOARD_H__
#define __BOARD_H__


volatile uint16_t buttonPressed;


void board_init(void);
void gpio_init();
void lfxtal_init();

void timer_B0_init();
void timer_A2_init();
void timer_A2_led(uint8_t state);

void acc_enable_orientation();
void acc_disable_orientation();
void acc_enable_hpf();
void acc_disable_hpf();
void acc_enable_click();
void acc_disable_4D();
void acc_enable_4D();
void acc_app_init();

uint8_t sleep_ms(uint16_t ms);
uint16_t reverse_bits(uint16_t word, uint16_t length);

#define RTC_TICK_COMPENSATION (69)
 
#endif /* __BOARD_H__ */ 
