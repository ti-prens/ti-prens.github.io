/**
Settings menu
*/
#ifndef SETTINGS_H_
#define SETTINGS_H_

void settings_time_set(void);

#endif