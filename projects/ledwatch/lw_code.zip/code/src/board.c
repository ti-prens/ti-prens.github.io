#include <stdint.h>
#include <stddef.h>
#include <msp430.h>
#include "board.h"
#include "disp.h"
#include "accel.h"
#include "clock.h"


uint8_t exitSignal = 0;
uint8_t exitMenu = 0;
uint8_t tapStatus = 0;

void ucs_init();
void board_init() {
	WDTCTL = WDTPW + WDTHOLD;   // Stop WDT
	
	gpio_init();
	display_init();
	ucs_init();
	lfxtal_init();
	timer_A2_init();
	timer_B0_init();

	__bis_SR_register(GIE); // Enable interrupts
}

void gpio_init() {
	// Pin direction 0-in 1-out
	P1DIR = 0xFF; // minutes leds
	P2DIR = 0xFF; // seconds leds
	P4DIR = 0xFF; // rf, uart, motor
	P5DIR = 0xFF; // uart cts/rts
	P6DIR = 0xFF; // hours leds
	P7DIR = BIT4 | BIT5 | BIT6 | BIT7; // P7.4-7 are not used
	PJDIR = 0xFF; // Jtag not used

	// Pin drive strength 0-low 1-high
	P1DS = 0x00;
	P2DS = 0x00;
	P4DS = 0x00; 
	P5DS = 0x00;
	P6DS = 0x00;
	P7DS = 0x00;
	PJDS = 0x00;

	// Pull up/down resistor enable
	P7REN = BIT0 | BIT1 | BIT2; // Enable pull resistors on interrupts
	
	// Output level / pull up/down select
	P1OUT = 0xFF;
	P2OUT = 0xFF;
	P4OUT = 0x00;
	P5OUT = 0x00;
	P6OUT = 0xFF;
	P7OUT = BIT4 | BIT5 | BIT6 | BIT7; // All interrupts active LOW
	PJOUT = 0x00;
}

//######################## CLOCKS #########################
void ucs_init()
{
	UCSCTL3 = SELREF_2;                       // Set DCO FLL reference = REFO
	UCSCTL4 |= SELA_2;                        // Set ACLK = REFO
	

	__bis_SR_register(SCG0);                  // Disable the FLL control loop
	UCSCTL0 = 0x0000;                         // Set lowest possible DCOx, MODx  
	UCSCTL1 = DCORSEL_5;                      // Select DCO range 16MHz operation
	UCSCTL2 = FLLD_1 + 249;                   // Set DCO Multiplier for 8MHz
												// (N + 1) * FLLRef = Fdco
												// (249 + 1) * 32768 = 8MHz
	__bic_SR_register(SCG0);                  // Enable the FLL control loop

	// Worst-case settling time for the DCO when the DCO range bits have been
	// changed is n x 32 x 32 x f_MCLK / f_FLL_reference. See UCS chapter in 5xx
	// UG for optimization.
	// 32 x 32 x 8 MHz / 32,768 Hz = 250000 = MCLK cycles for DCO to settle
	__delay_cycles(250000);
	
	// Loop until XT1,XT2 & DCO stabilizes - In this case only DCO has to stabilize
	do
	{
		UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + DCOFFG);
												// Clear XT2,XT1,DCO fault flags
		SFRIFG1 &= ~OFIFG;                      // Clear fault flags
	}while (SFRIFG1&OFIFG);               	    // Test oscillator fault flag
}

void lfxtal_init() {
	// Configure XT1
	P5SEL |= BIT4+BIT5;                       // Port select XT1
	UCSCTL6 &= ~(XT1OFF);                     // XT1 On
	UCSCTL6 |= XCAP_3;                        // Internal load cap
	UCSCTL3 = 0;                              // FLL Reference Clock = XT1
	// Loop until XT1,XT2 & DCO stabilizes - In this case loop until XT1 and DCo settle
	do
	{
	UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + DCOFFG);
											// Clear XT2,XT1,DCO fault flags
	SFRIFG1 &= ~OFIFG;                      // Clear fault flags
	}while (SFRIFG1&OFIFG);                   // Test oscillator fault flag  
	UCSCTL6 &= ~(XT1DRIVE_3);                 // Xtal is now stable, reduce drive strength
	UCSCTL4 |= SELA_0;                        // ACLK = LFTX1 (by default)
}

//######################## TIMERS #############################

void timer_B0_init() {
	P7DIR = 0;          // Input mode
	P7SEL = BIT3 | BIT2 | BIT1;       // Select pushbutton, accelerometer 1 and 2

	TB0CCTL3 = CM_2 + CCIS_1 + CAP + CCIE;     // Falling edge capture enabled on P7.3
	TB0CCTL2 = CM_2 + CCIS_1 + CAP + CCIE;     // Falling edge capture enabled on P7.2
	// TB0CCTL1 = CM_2 + CCIS_1 + CAP + CCIE;     // Falling edge capture enabled on P7.1
	TB0CTL = TBSSEL_1 + MC_2 + TBCLR + TBIE;   // ACLK, contmode, clear TBR, Interrupt enabled
}

void timer_A2_init() {
	TA2CCTL0 = CCIE;               // CCR0 toggle, interrupt enabled (LED refresh)
	TA2CCTL1 = CCIE;               // CCR1 toggle, interrupt enabled (software RTC)
	TA2CCR1  = 32768; // Add offset to CCR1
	// TA2CCTL2 = OUTMOD_4 + CCIE;               // CCR2 toggle, interrupt enabled 
	TA2CTL = TASSEL_1 + MC_2 + TACLR + TAIE;  // ACLK, contmode, clear TAR, interrupt enabled
}

void timer_A2_led(uint8_t state) {
	if(state == 0) TA2CCTL0 = 0;
	else TA2CCTL0 = OUTMOD_4 + CCIE;
}


//####################################### ACCELEROMETER INIT ###################################

void acc_enable_orientation() {
	acc_intgen_config(IG_6D_POS | I1_YL);  // Enable 'd' position detection
	acc_intgen_duration(900);              // User has to stay in position for 500ms
	acc_intgen_threshold(700);             // Set threshold to 0.9 G
}

void acc_disable_orientation() {
	acc_intgen_config(0);  // disable position detection
}

void acc_enable_hpf() {
	acc_hpf_config(HP_MODE_NORMAL | HPCLICK); // Enable hpf on click only, fc = 1Hz @ fs=50Hz
}

void acc_disable_hpf() {
	acc_hpf_config(0);
}

void acc_enable_click() {
	acc_click_set(TAP_ZD, // Enable Z double-tap, X and Y single-tap
				  800,                      // Tap-threshold is 0.3 G
				  200,                      // Tap detected if acc_value decreases within 180ms
				  80,                       // Pause 80ms before starting double-tap detection
				  100);                     // User has to tap again withing 100 ms to register 
											// a double-tap
}

void acc_disable_4D() {
	acc_write_reg(0x38, TAP_ZD); // Write tap_cfg
}

void acc_enable_4D() {
	acc_write_reg(0x38, TAP_ZD | TAP_YS | TAP_XS); // Write tap_cfg
}

void acc_app_init() {
	acc_init();      // Init accelerometer
	acc_lowpower(1); // Set low-power mode
	acc_enable_orientation(); // Enable orientation detection
	// acc_disable_orientation();
	acc_enable_hpf();         // Enable high pass filter on click/tap detection
	// acc_disable_hpf();
	acc_enable_click();       // Enable click detection on 6 axes
	acc_disable_4D();         // Enable only Z-axis double-click

	acc_int1_sources(I1_CLICK); // Tap-detection interrupt on output 1
	acc_int2_sources(I2_CLICK | I2_IG1 | I2_HLACTIVE);   // Orientation detection interrupt on output 2
}

//####################################### UTILITY FUNCTIONS ####################################

uint16_t reverse_bits(uint16_t word, uint16_t length) {
	// Bitwise bit reversal function
	uint16_t r = 0; // Contains reversed word
	uint16_t i;

	if(length == 8) 
		word &= 0xFF;
	else 
		word &= (1<<length) - 1;

	for (i = length - 1; i > 0; i--)
	{
		r |= word & 0x01;
		r <<= 1;
		word >>= 1;
	}
	r |= word & 0x01;

	return r;
}

uint8_t sleep_ms(uint16_t ms) {
	exitSignal = 0;

	while((!exitSignal) && (ms != 0)) {
		__delay_cycles(8000);
		ms--;
	}
	return exitSignal;
}

