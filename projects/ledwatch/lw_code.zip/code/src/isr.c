#include <stdint.h>
#include <stddef.h>
#include <msp430.h>
#include "board.h"
#include "disp.h"
#include "accel.h"
#include "clock.h"

extern uint8_t exitSignal;
extern uint8_t exitMenu;
extern uint8_t tapStatus;

//####################################################################################
//                           Interrupt Service Routines
//####################################################################################


// Timer2 A0 interrupt service routine
void __attribute__ ((interrupt(TIMER2_A0_VECTOR))) Timer2_A0 (void)
{
	TA2CCR0 += 30;                             // Add Offset to CCR0
	display_refresh();
}

// Timer2_A1 Interrupt Vector (TAIV) handler
void __attribute__ ((interrupt(TIMER2_A1_VECTOR))) TIMER2_A1_ISR (void)
{
 switch(__even_in_range(TA2IV,14))
	{
	case 0:  break;             
	case 2:  
		// ACLK = LFTX1 = 32768 Hz
		// CCR1 = ACLK * T - 1
		// CCR1 = 32768 * 1 - 1 (1 sec period)
		TA2CCR1 += 32768 + RTC_TICK_COMPENSATION; // Add offset to CCR1
		// TA2CCR1 += 32768; // Add offset to CCR1
		// P5OUT ^= BIT2;

		// Software RTC
		clock_increment_seconds();
		break;     
	case 4:  
		TA2CCR2 += 10000;  // Add Offset to CCR2
		break;
	case 6:  break;                         // CCR3 not used
	case 8:  break;                         // CCR4 not used
	case 10: break;                         // CCR5 not used
	case 12: break;                         // Reserved not used
	case 14: break;
	default: break;
 }
}

// Timer1_B Overflow ISR
void __attribute__ ((interrupt(TIMER0_B0_VECTOR))) TIMERB0_ISR (void)
{
}

// Timer1_B ISR (TBIV) handler
void __attribute__ ((interrupt(TIMER0_B1_VECTOR))) TIMERB1_ISR (void)
{
	/* Any access, read or write, of the TBIV register automatically resets the
	highest "pending" interrupt flag. */
	switch( __even_in_range(TBIV,14) )
	{
	case  0: break;                          // No interrupt
	case  2: // Accelerometer Interrupt 1
		// Click interrupt
		// buttonPressed = 1;
		// exitSignal = 1; // If uC is idling, return to main
		// tapStatus = 1;
		__bic_SR_register_on_exit(LPM3_bits); // Exit LPM3
		break;

	case  4: // Accelerometer Interrupt 2
		// Orientation interrupt
		// exitSignal = 1; // If uC is idling, return to main
		tapStatus = 1;
		// exitMenu = 1;
		__bic_SR_register_on_exit(LPM3_bits); // Exit LPM3
		break;

	case  6: // Pushbutton Interrupt
		buttonPressed = 1;
		exitSignal = 1;
		__bic_SR_register_on_exit(LPM3_bits); // Exit LPM3
		break;

	case  8: break;                          // CCR4 not used
	case 10: break;                          // CCR5 not used
	case 12: break;                          // CCR6 not used
	case 14: break;                          // Overflow
	default: break;
	}
}

// I2C ISR handler (TX/RX)
void __attribute__ ((interrupt(USCI_B0_VECTOR))) USCI_B0_ISR (void)
{
	switch(__even_in_range(UCB0IV,12))
	{
	case  0: break;                           // Vector  0: No interrupts
	case  2: break;                           // Vector  2: ALIFG
	case  4: break;                           // Vector  4: NACKIFG
	case  6: break;                           // Vector  6: STTIFG
	case  8: break;                           // Vector  8: STPIFG
	case 10:                                  // Vector 10: RXIFG
	RXByteCtr--;                            // Decrement RX byte counter
	if (RXByteCtr)
	{
		*PRxData++ = UCB0RXBUF;               // Move RX data to address PRxData
		if (RXByteCtr == 1)                   // Only one byte left?
		UCB0CTL1 |= UCTXSTP;                // Generate I2C stop condition
	}
	else
	{
		*PRxData = UCB0RXBUF;                 // Move final RX data to PRxData
		// UCB0CTL1 |= UCTXNACK;
		// UCB0CTL1 |= UCTXSTP;                  // I2C stop condition     

		UCB0IFG &= ~UCRXIFG;
		__bic_SR_register_on_exit(LPM0_bits); // Exit LPM0
	}
	break; 


	case 12:                                  // Vector 12: TXIFG  
	if (TXByteCtr)                          // Check TX byte counter
	{
		UCB0TXBUF = *PTxData++;               // Load TX buffer
		TXByteCtr--;                          // Decrement TX byte counter
	}
	else
	{
		UCB0CTL1 |= UCTXSTP;                  // I2C stop condition
		UCB0IFG &= ~UCTXIFG;                  // Clear USCI_B0 TX int flag
		__bic_SR_register_on_exit(LPM0_bits); // Exit LPM0
	}  
	default: break;
	}
}
