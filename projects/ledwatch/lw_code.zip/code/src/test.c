#include <stdint.h>
#include <stddef.h>
#include <msp430.h>
#include "board.h"
#include "disp.h"
#include "accel.h"
#include "clock.h"
#include "test.h"

void test_tilt() {
	int acc_x,acc_y,acc_z;
	timer_A2_led(1); // Enable display interrupt

	while(!buttonPressed) {
		acc_read3(&acc_x, &acc_y, &acc_z);

        if(acc_x > 1000) {
            display[0] = 0b01100000;
            display[1] = 0b01100000;
            display[2] = 0b01100000;
        }
        else if(acc_x < -1000) {
            display[0] = 0b00000110;
            display[1] = 0b00000110;
            display[2] = 0b00000110;
        }
        else {
            display[0] = 0b00011000;
            display[1] = 0b00011000;
            display[2] = 0b00011000;
        }

        if(acc_y > 1000) {
            display[1] = 0;
            display[2] = 0;
        }
        else if(acc_y < -1000) {
            display[0] = 0;
            display[1] = 0;
        }
        else {
            display[0] = 0;
            display[2] = 0;
        }

		sleep_ms(100);
	}
	buttonPressed = 0;
}

void test_click() {
	uint8_t hours, minutes, seconds;
	uint8_t click = 0;
	uint8_t cfg = 0;
	uint16_t time_elapsed_ms;

	while(!buttonPressed) {
		time_elapsed_ms = 0;
		display_clear();
		__bis_SR_register(LPM3_bits + GIE); // sleep until interrupt

		while(time_elapsed_ms < 10000 && !buttonPressed)
		{
			// clock_get_time(&hours, &minutes, &seconds);
			// display_bcd(hours, minutes, seconds, 100);
			time_elapsed_ms += 100;
		}
	}
	buttonPressed =0;
}

void test_clock_bcd() {
	time_struct_t* time_p;
	uint16_t time_elapsed_ms;

	while(!buttonPressed) {
		time_elapsed_ms = 0;
		display_clear();
		__bis_SR_register(LPM3_bits + GIE); // sleep until interrupt
		time_p = clock_get_time_p(); // Get pointer to current time struct

		while(time_elapsed_ms < 10000 && !buttonPressed)
		{
			display_bcd(time_p->hours, time_p->minutes, time_p->seconds, 100);
			time_elapsed_ms += 100;
		}
	}
	buttonPressed =0;
}

void test_clock_numbers() {
	time_struct_t* time_p;
	uint16_t time_elapsed_ms;

	while(!buttonPressed) {
		time_elapsed_ms = 0;
		display_clear();
		__bis_SR_register(LPM3_bits + GIE); // sleep until interrupt
		time_p = clock_get_time_p(); // Get pointer to current time struct

		while(time_elapsed_ms < 4000 && !buttonPressed)
		{
			display_number(time_p->hours, 1000);
			display_number(time_p->minutes, 1000);
			time_elapsed_ms += 2000;
		}
	}
	buttonPressed =0;
}

void test_4D() {
	return;
}

void test_graph() {
	return;
}

