#include <msp430.h>
#include <stdint.h>
#include <stddef.h>
#include "disp.h"
#include "alphabet.h"
#include "board.h"

void display_init() {
	P6DIR = 0xFF;
	P1DIR = 0xFF;
	P2DIR = 0xFF;

	P6DS = 0xFF;
	P1DS = 0xFF;
	P2DS = 0xFF;

	P6OUT = 0xFF;
	P1OUT = 0xFF;
	P2OUT = 0xFF;

	// Display state
	display[0] = 0x00; // Top
	display[1] = 0x00; // Bottom
	display[2] = 0x00; // Middle
	display[3] = 0x01; // channel
}

void display_refresh() {
	uint16_t state = display[3];

	if(state == 0) {
		P6OUT = 0xFF;
		P1OUT = 0xFF;
		P2OUT = 0xFF;
		return; // Display is disabled
	}
	else if(state == 0x80) // Channel counter overflow
		state = 0x01;
	else 
		state <<= 1;

	P6OUT = ~(reverse_bits(display[0], 8) & 0xFF & reverse_bits(state,8));
	P1OUT = ~(display[1] & 0xFF & state);
	P2OUT = ~(display[2] & 0xFF & state);

	display[3] = state;
}

void display_clear() {
	display[0] = 0;
	display[1] = 0;
	display[2] = 0;
	display[3] = 1; 
	// display[3] = 0; // Disable display refresh interrupt
}

void display_bytes(int top, int mid, int bot, uint16_t time_ms) {
	display[0] = top & 0xFF;
	display[1] = mid & 0xFF;
	display[2] = bot & 0xFF;

	display[3] = 1; // Enable display refresh interrupt

	sleep_ms(time_ms);
	display[3] = 0;
}

void display_bcd(uint16_t top, uint16_t mid, uint16_t bot, uint16_t time_ms) {
	if(top>99) return;
	if(mid>99) return;
	if(bot>99) return;
	display[0] = ((top/10)<<4) + (top%10);
	display[1] = ((mid/10)<<4) + (mid%10);
	display[2] = ((bot/10)<<4) + (bot%10);

	// display[3] = 1; // Enable display refresh interrupt

	sleep_ms(time_ms);
}

void display_number(uint16_t num, uint16_t time_ms) {
	if(num>99) return;
	display[0] = numbers[0][num % 10] + (numbers[0][num / 10]<<5);
	display[1] = numbers[1][num % 10] + (numbers[1][num / 10]<<5);
	display[2] = numbers[2][num % 10] + (numbers[2][num / 10]<<5);

	display[3] = 1; // Enable display refresh interrupt

	sleep_ms(time_ms);
	display[3] = 0;
}

void display_string(char* string, uint16_t repeat, uint16_t scrollspeed) {
	uint16_t i = 0;
	uint16_t j = 0;
	char currentChar = 0;

	display[3] = 1; // Enable display refresh interrupt

	repeat++;
	while(repeat != 0) {
		repeat--;
		i = 0;
		j = 0;

		for(;string[j] != 0;j++) {

			currentChar = string[j];
			if((currentChar<'a' || currentChar>'z') && currentChar!=' ') return;
			if(currentChar == ' ') currentChar = 0x7B; // conversion from ASCII space to current alphabet

			for(i=5;i>0;i--) {
				display[0] = (display[0]<<1);
				display[1] = (display[1]<<1);
				display[2] = (display[2]<<1);

				display[0] += (letters[0][currentChar - 'a']>>i) & 1;
				display[1] += (letters[1][currentChar - 'a']>>i) & 1;
				display[2] += (letters[2][currentChar - 'a']>>i) & 1;
				if(sleep_ms(scrollspeed) != 0) return;
			}
		}

		for(j=2;j>0;j--) {
			currentChar = 0x7B;
			for(i=5;i>0;i--) {
				display[0] = (display[0]<<1);
				display[1] = (display[1]<<1);
				display[2] = (display[2]<<1);

				display[0] += (letters[0][currentChar - 'a']>>i) & 1;
				display[1] += (letters[1][currentChar - 'a']>>i) & 1;
				display[2] += (letters[2][currentChar - 'a']>>i) & 1;
				if(sleep_ms(scrollspeed) != 0) return;
			}
		}
	}

	display[3] = 0;
} 

void wait_ms(int ms) {
	for(;ms>0;ms--) {
		__delay_cycles(1000);
	}
}

