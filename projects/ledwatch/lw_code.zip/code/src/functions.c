/*

Watch functions:

- time settings
- chrono
- timer
- pomodoro timer
- bpm set
- test mode
- main settings:
	- bpm led/vibration/both
	- notification: led/vibration/both
	- time light-up frequency
	- time light-up triggers & thresholds: angle/tap/movement
	- led animations & frequency

Reset to time display by shaking wrist

Chrono: bcd display (minutes, seconds, hundreds)
	- Start/stop chrono with single tap
	- Lap with double tap
	- Reset by stopping and double tap

Timer: bcd/digital display (hours, minutes, seconds)
	- Start/stop with single tap
	- Set to background with single tap
	- Remembers previous duration
	- Double tap to change duration when stopped

Pomodoro timer: bcd/digital display
	- Start/break with single tap
	- Pause with double tap
	- Remembers previous settings
	- Set with double tap (when stopped)
	- Reset by flipping watch face down

Metronome: hybrid bcd display (song num, bpm, flashing bpm row)
	- Set by tapping 10 times OR double tap and select number
	- Song function TBD

Test:
	- cycle through tests with double-taps
	- exit with double button press
	- Tests:
		- Tilt left/right
		- Tilt up/down
		- Single tap / double tap
		- Vibration motor (s.o.s pattern)
		- LED dimming
		- LED display (low speed signle pixel scroll)
		- Exit

*/