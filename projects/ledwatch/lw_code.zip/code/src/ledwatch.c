#include <msp430.h>
#include <stdint.h>
#include <stddef.h>
#include "board.h"
#include "disp.h"
#include "accel.h"
#include "test.h"
#include "clock.h"
#include "settings.h"

#define DSPEED 80



void main(void)
{
	time_struct_t* time_p;
	
	board_init();

	time_p = clock_get_time_p();
	time_p->hours   = 12;
	time_p->minutes = 00;
	time_p->seconds = 00;

	sleep_ms(2000);

	acc_app_init();
	acc_write_reg(0x24, 0x00); // Disable latched interrupts

	display_clear();

	while(1) {
		display_string("bcd",0,80);
		test_clock_bcd();
		display_string("digital",0,80);
		test_clock_numbers();
		display_string("tilt",0,80);
		test_tilt();
		settings_time_set();
	}
}
