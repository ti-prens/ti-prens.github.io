
/*
Item selector function:
- Inputs: array of item descriptions (strings)
- Outputs: item index
- Control schemes:
	- acceleration up/down to show item strings, tap to select, double-tap exit
	- up/down taps to select item, right tap to select, left tap to exit

Number selector function:
- Inputs: 2 ints: start and end numbers, display mode (bin/bcd/digit)
- Output: selected number
- Control schemes:
	- accel up/down to select number, double-tap to select

*/
#include <stdint.h>
#include "board.h"
#include "disp.h"
#include "accel.h"

extern uint8_t exitMenu;
extern uint8_t exitSignal;
extern uint8_t tapStatus;

#define ITEM_SCROLL_THR 5000
#define TILT_ANGLE_COMPENSATION +2000

uint8_t 
itemSelector(char* itemNames, uint8_t inputStyle)
{
	/*
	if(inputStyle == STYLE_MOVEMENT)
	{
		int accel;
		tap_struct_t tapStatus;
		uint16_t scrollSpeed = 80;
		uint8_t i = 0;

		// Clear tap events in accelerometer memory
		acc_intgen_event();

		while(!exitSignal)
		{
			// Display current item names
			dispString(itemNames[i], scrollSpeed);
			// Display text separator
			dispString("   ", scrollSpeed);

			// Retrieve acceleration/orientation data
			accel = acc_read_x();
			// Scroll speed is proportionnal to tilt angle
			// scrollSpeed = abs(accel);
			// Retrieve tap status
			getTap(&tapStatus);
			
			// Item selection
			if(tapStatus->double_tap)
				return 0xFF; // Return no item selected value
			else if(tapStatus->single_tap)
				return i; // Return selected item

			// Item incrementation
			if(accel > ITEM_SCROLL_THR)
				i++;
			else if(accel < -ITEM_SCROLL_THR)
				i--;
		}
	}

	/*
	else if(inputStyle == STYLE_2D_TAPS)
	{
		tap_2d_struct_t tap2d;
		uint8_t i = 0;

		// Clear 2D tap events in accelerometer memory
		clear2DTap();

		while(!exitSignal)
		{
			// Display current item names
			dispString(itemNames[i], textScrollSpeed);
			// Display text separator
			dispString("   ", textScrollSpeed);

			// Retrieve 2D tap status
			get2DTap(&tap2d);
			
			// Item selection
			if(tap2d->y < 0)
				return 0xFF; // Return no item selected value
			else if(tap2d->y > 0)
				return i; // Return selected item

			// Item incrementation
			if(tap2d->x > 0)
			{
				// Increment item index
				i++;
				// Clear 2D tap events in accelerometer memory
				clear2DTap();
			}
			else if(tap2d->x < 0)
			{
				// Decrement item index
				i--;
				// Clear 2D tap events in accelerometer memory
				clear2DTap();
			}
		}
	}
	*/

	return 0;
}

uint16_t 
numberSelector(uint16_t defaultNum, uint16_t startNum, uint16_t endNum, uint8_t displayType)
{
	uint16_t currentNumber = defaultNum;
	int accel;
	// uint8_t tapStatus;
	uint16_t dispTime = 1000;

	// Clear previous tap events
	acc_intgen_event();
	acc_click_event();
	tapStatus = 0;

	while(!exitSignal)
	{
		// Display current number
		switch(displayType)
		{
			case DISPLAY_DIGITAL:
			display_number(currentNumber, dispTime);
			break;
			case DISPLAY_BCD:
			display_bcd(0, currentNumber, 0, dispTime);
			break;
			default:
			display_bcd(0, currentNumber, 0, dispTime);
			break;
		}

		// Get tap status
		// tapStatus = acc_intgen_event();
		// tapStatus = acc_click_event();
		// Get acceleration data
		accel = acc_read_y();
		accel += TILT_ANGLE_COMPENSATION;
		// Display time is proportional to tilt angle
		dispTime = abs(accel) / 12;
		dispTime = 1500 - dispTime;

		if(tapStatus)
		{
			tapStatus = 0;
			return currentNumber;
		}

		// Increment/decrement number
		if(accel > ITEM_SCROLL_THR)
		{
			if(currentNumber < endNum)
				currentNumber++;
			else
				currentNumber = startNum;
		}
		else if(accel < -ITEM_SCROLL_THR)
		{
			if(currentNumber > startNum)
				currentNumber--;
			else 
				currentNumber = endNum;
		}

	}
	exitMenu = 0;

	return currentNumber;
}